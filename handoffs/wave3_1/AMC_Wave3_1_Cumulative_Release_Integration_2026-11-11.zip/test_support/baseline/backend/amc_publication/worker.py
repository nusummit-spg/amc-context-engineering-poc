"""Restart-safe publication worker with real effect preimages and readback checks.

IMPORTANT: The filesystem snapshot artifact is a correctness reference, *not*
a loaded FAISS generation. Production integration must replace the snapshot
adapter with FaissGenerationBuilder and verify its index before activation.
Until then this worker must not be wired to the legacy serving path.
"""
from .types import Claim, Conflict, Generation, LeaseLost, VerificationFailed
from .journal import Journal
from .artifacts import ImmutableSnapshotStore
from .graph import GraphPort, InMemoryGraphPort
from .faiss_artifacts import FaissGenerationStore


class PublicationWorker:
    def __init__(self, journal: Journal, graph: GraphPort, artifacts: ImmutableSnapshotStore,
                 owner: str = "worker-1", failpoint=None, simulation_mode: bool = False,
                 serving_probe=None):
        if not simulation_mode:
            if not isinstance(artifacts, FaissGenerationStore):
                raise ValueError("production worker requires verified immutable FAISS binary generations")
            if isinstance(graph, InMemoryGraphPort):
                raise ValueError("production worker cannot use in-memory graph port")
            if not callable(serving_probe):
                raise ValueError("production activation needs an active FAISS reader probe")
        self.simulation_mode = simulation_mode
        self.serving_probe = serving_probe
        self.journal = journal
        self.graph = graph
        self.artifacts = artifacts
        self.owner = owner
        self.failpoint = failpoint or (lambda stage: None)

    def run_once(self):
        claim = self.journal.claim(self.owner)
        if claim is None:
            return {"status": "idle"}
        try:
            if claim.mode == "rollback":
                return self._rollback(claim)
            return self._publish(claim)
        except Exception as exc:
            # Do not hide errors. Leave durable job retryable and provide reason.
            try:
                self.journal.retry(claim, exc)
            except LeaseLost:
                return {"status": "stale_worker", "id": claim.work_id}
            return {"status": "retry_scheduled", "id": claim.work_id, "error": str(exc)}
        # Process killed (BaseException), power loss etc. are intentionally
        # not caught: recover by lease expiry and durable replay.

    def _publish(self, c: Claim):
        p = c.payload
        entity, field = p["entity"], p["attribute"]
        target = f"{entity}:{field}"
        desired = {"value": p["corrected_value"]}
        docs = p["full_vector_snapshot"]

        prior = self.journal.effect(c.work_id, "graph", target)
        observed_pre = self.graph.read(c.tenant, entity, field)
        graph_pre = prior["pre"] if prior else observed_pre
        graph_pre = self.journal.prepare(c, kind="graph", target=target,
                                         pre=graph_pre, post=desired)
        self.failpoint("graph_preimage_committed")
        self.journal.assert_lease(c)
        self.graph.compare_and_set(c.tenant, entity, field, graph_pre, desired["value"], c.fence)
        self.failpoint("graph_written")
        observed = self.graph.read(c.tenant, entity, field)
        if observed != desired:
            raise VerificationFailed("Neo4j readback differs from proposed correction")
        self.journal.verified(c, kind="graph", target=target, observed=observed)
        self.failpoint("graph_verified")

        artifact = self.artifacts.stage(c.tenant, docs)
        self.artifacts.verify(artifact, c.tenant)
        current_ptr = self.journal.pointer(c.tenant)
        vector_post = {"generation_id": artifact.generation_id, "digest": artifact.digest}
        previous = self.journal.effect(c.work_id, "vector", "vector_faiss")
        before_ptr = previous["pre"] if previous else current_ptr
        before_ptr = self.journal.prepare(c, kind="vector", target="vector_faiss",
                                          pre=before_ptr, post=vector_post)
        self.failpoint("vector_preimage_committed")
        self.journal.assert_lease(c)
        self.journal.switch_pointer(c, namespace="vector_faiss", expected=before_ptr,
                                    new_id=artifact.generation_id, digest=artifact.digest)
        self.failpoint("pointer_switched")
        after_ptr = self.journal.pointer(c.tenant)
        if after_ptr["generation_id"] != artifact.generation_id or after_ptr["digest"] != artifact.digest:
            raise VerificationFailed("active vector pointer readback mismatched")
        if self.artifacts.verify(artifact, c.tenant) != ImmutableSnapshotStore._canonical_documents(c.tenant, docs):
            raise VerificationFailed("corpus readback mismatch")
        self.journal.verified(c, kind="vector", target="vector_faiss", observed=vector_post)
        self.failpoint("vector_verified")
        if self.serving_probe is not None and not self.serving_probe(c.tenant, artifact.generation_id, artifact.digest):
            raise VerificationFailed("live FAISS serving reader has not loaded/verified active generation")

        receipt_id = self.journal.publish(c)
        return {"status": "published", "id": c.work_id, "receipt_id": receipt_id,
                "generation": artifact.generation_id}

    def _rollback(self, c: Claim):
        p = c.payload
        entity, field = p["entity"], p["attribute"]
        target = f"{entity}:{field}"
        graph = self.journal.effect(c.work_id, "graph", target)
        vector = self.journal.effect(c.work_id, "vector", "vector_faiss")
        if not graph or not vector or graph["state"] not in ("verified", "compensated") or vector["state"] not in ("verified", "compensated"):
            raise Conflict("cannot roll back publication without verified durable effect preimages")

        # Swap active pointer first. If crash follows, replay sees that pointer
        # already reverted; graph still needs compensation. Never return OK early.
        before = vector["pre"]
        after = vector["post"]
        current = self.journal.pointer(c.tenant)
        if current["generation_id"] == after["generation_id"]:
            if before["generation_id"]:
                # Verify previous generation bytes before switching to it.
                old = Generation(before["generation_id"], before["digest"],
                                 len(self.artifacts.verify_by_digest(before["digest"], c.tenant)))
                self.artifacts.verify(old, c.tenant)
            self.journal.switch_back(c, current_id=after["generation_id"],
                                      current_digest=after["digest"], before=before)
        elif current["generation_id"] != before["generation_id"]:
            raise Conflict("generation pointer diverged from both expected before/after")
        self.journal.compensate(c, "vector", "vector_faiss")
        self.failpoint("vector_rollback_committed")

        self.graph.compare_and_set(c.tenant, entity, field,
                                   graph["post"], graph["pre"]["value"], c.fence)
        if self.graph.read(c.tenant, entity, field) != graph["pre"]:
            raise VerificationFailed("graph rollback exact preimage readback mismatch")
        self.journal.compensate(c, "graph", target)
        self.failpoint("graph_rollback_committed")
        self.journal.finish_rollback(c)
        return {"status": "rolled_back", "id": c.work_id}
