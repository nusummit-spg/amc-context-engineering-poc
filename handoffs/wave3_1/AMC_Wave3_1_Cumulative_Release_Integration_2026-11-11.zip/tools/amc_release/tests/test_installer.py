import importlib.util
import tempfile
import unittest
from pathlib import Path

SRC = Path(__file__).resolve().parents[3]
SPEC = importlib.util.spec_from_file_location('install_wave24', SRC / 'install_wave24.py')
M = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(M)


class InstallerTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.repo=Path(self.temp.name)/'repo'
        for d in ('.git', 'backend', 'mf-context-engine'):
            (self.repo/d).mkdir(parents=True)
    def test_dry_run_does_not_copy(self):
        # Full handoff creates status/docs at packaging time; use custom miniature manifest.
        original=M.FILES[:];M.FILES[:]=['tools/amc_release/common.py']
        try:
            r=M.install(SRC,self.repo)
            self.assertEqual(r['new'],1)
            self.assertFalse((self.repo/'tools/amc_release/common.py').exists())
        finally: M.FILES[:]=original
    def test_apply_non_overwriting(self):
        original=M.FILES[:];M.FILES[:]=['tools/amc_release/common.py']
        try:
            self.assertEqual(M.install(SRC,self.repo,apply=True)['applied'],1)
            self.assertEqual(M.install(SRC,self.repo,apply=True)['same'],1)
            (self.repo/'tools/amc_release/common.py').write_text('local modification')
            with self.assertRaises(FileExistsError): M.install(SRC,self.repo,apply=True)
        finally: M.FILES[:]=original
    def test_refuses_non_checkout(self):
        with self.assertRaises(ValueError): M.install(SRC,Path(self.temp.name))


if __name__=='__main__':unittest.main()
