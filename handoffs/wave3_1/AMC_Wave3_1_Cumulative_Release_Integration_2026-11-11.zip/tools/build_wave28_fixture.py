"""Build an isolated upgraded Journal fixture from historical Wave 1.9 source.

Never writes to the AMC application checkout. Current GitHub bytes must still be
reviewed using source-locked patcher before deployment.
"""
from pathlib import Path
import shutil
from tools.amc_release import publication_patch25 as w25, publication_patch26 as w26, active_cutover28 as w28

ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'test_support/baseline/backend/amc_publication'
DEST=ROOT/'test_support/wave28_fixture/backend/amc_publication'


def build():
    if DEST.exists():shutil.rmtree(DEST)
    shutil.copytree(SRC,DEST,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
    j=(DEST/'journal.py').read_text()
    old='''    def switch_back(self, claim: Claim, *, current_id: str, current_digest: str, before: dict):
        """Restores an existing previous generation; empty baseline requires a dedicated deactivation."""
        with self.sessions.begin() as s:
            self._require(s, claim)
            row = s.get(GenerationPointer, (claim.tenant, "vector_faiss"))
            if not row or row.generation_id != current_id or row.artifact_digest != current_digest:
                raise Conflict("active pointer changed; manual rollback reconciliation required")
            if before["generation_id"] is None:
                # No prior corpus: delete only the exact generation being rolled back.
                s.delete(row)
            else:
                row.generation_id, row.artifact_digest = before["generation_id"], before["digest"]
                row.epoch += 1
                row.activated_at = utcnow()
'''
    new='''    def switch_back(self, claim: Claim, *, current_id: str, current_digest: str, before: dict):
        """CAS-restore the pointer to the previous verified generation.

        REC03 / W22-11 fix: when a prior generation exists (before["generation_id"]
        is not None), restore it via CAS rather than deleting the pointer.
        Only delete when rolling back the very first publication (no prior generation).
        Raises Conflict if another writer has changed the pointer since publication.
        """
        with self.sessions.begin() as s:
            self._require(s, claim)
            row = s.get(GenerationPointer, (claim.tenant, "vector_faiss"))
            if not row or row.generation_id != current_id or row.artifact_digest != current_digest:
                raise Conflict(
                    "active pointer changed since publication; "
                    "manual rollback reconciliation required"
                )
            if before.get("generation_id") is None:
                # First-ever generation: deactivate explicitly by removing the row.
                s.delete(row)
            else:
                # Restore to the previous verified generation via CAS.
                row.generation_id = before["generation_id"]
                row.artifact_digest = before["digest"]
                row.epoch += 1
                row.activated_at = utcnow()
'''
    if j.count(old)!=1:raise ValueError('historical journal source has drifted')
    j=j.replace(old,new)
    j=w25.harden_journal(j)
    j=w26.harden_journal26(j)
    j=w28.journal28(j)
    compile(j,'journal.py','exec')
    (DEST/'journal.py').write_text(j)
    for name in ('active_authority28.py','serving27.py','serving28.py','faiss_reader27.py','reconcile27.py','vector_bridge28.py','ingestion_boundary29.py','request_fence29.py','scope_audit31.py'):
        source=ROOT/'backend/amc_publication'/name
        if source.exists():shutil.copy2(source,DEST/name)
    return DEST

if __name__=='__main__':print(build())
