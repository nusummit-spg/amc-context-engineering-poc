# AMC Context Engineering POC — Wave 2.8 implementation and release-candidate handoff

**Date:** 11 November 2026 (Asia/Kolkata)  
**Repository:** `nusummit-spg/amc-context-engineering-poc`  
**Reviewed branch / SHA:** `amc-dev` at `2c0415c4d23a3338428c8314c869299aa0ab771f`  
**Write permission:** unavailable (`pull=true`, `push=false`)  
**Current release verdict:** **BLOCK — not UAT eligible**

## 1. Executive engineering decision

Wave 2.7 built a proof-checked FAISS reader but **left two critical production gaps**: (1) the active pointer had no unique durable active receipt identity when multiple publications use the same content-addressed generation, and (2) AMC's real `UserScopedVectorStore` / `RetrievalOrchestrator` still read from the legacy FAISS index, semantic cache, fast path, and shadow correction overlays.

**Wave 2.8 implements the next major cutover boundary**, rather than adding another independent assurance framework:

`Reviewed proposal → Journal + fenced publication → pre-graph serving suspension → exact Neo4j graph readback + immutable FAISS generation → pointer CAS → verified receipt and active-receipt binding committed together → tenant-scoped serving → rollback suspension → both compensations → previous exact receipt binding restored`.

In strict mode, legacy vector retrieval, semantic cache hits, unverified patch overlays, incorrect tenant context, and unbound source material are denied rather than silently served. The code is **opt-in** and must not be enabled globally until integrated into the full AMC application and staging services. Existing ingestion writes through `get_vector_store()` need to be separated into a trusted publisher path before strict serving is enabled.

### Evidence boundary

The current environment has full prior **Wave 2.7 local packages**, not a live network clone of the entire GitHub repository. Container DNS cannot resolve GitHub; the GitHub connector is read-only. The implementation was tested against **an isolated Wave 1.9 journal upgraded through the Wave 2.5 and 2.6 source transforms** and simulated FAISS-reader contracts. The actual repository files were separately audited via the GitHub connector, but the source patches were **not applied to the full checkout**. This distinction is material and no live acceptance is claimed.

## 2. New executable deliverables

| Component | Function and invariant | Verification |
|---|---|---|
| `backend/amc_publication/active_authority28.py` | Durable single active `(tenant,namespace,generation,digest,pointer_epoch,work_id,receipt_id)` sidecar; immutable per-work authority preimage; fails closed before graph mutation, on rollback, and on stale association | Real SQLAlchemy/SQLite transactions, adversarial tests |
| `backend/amc_publication/serving28.py` | Extends verified-generation resolver to select **only** the currently bound receipt; rechecks after loading actual reader | Durable resolver tests; duplicate historical receipt cases |
| `backend/amc_publication/vector_bridge28.py` | AMC `search` and `similarity_search` interface with verified FAISS backend; tenant/user restrictions, taxonomy and metadata filters, normalized scores; rejects legacy method fallback | Asynchronous interface/tenant isolation contract tests |
| `backend/alembic/versions/013_active_receipt_authority_v28.py` | Additive, nullable-free active authority schema + per-work predecessor history, no auto-backfill from legacy pointers | Actual SQLite upgrade/downgrade rehearsal |
| `tools/amc_release/active_cutover28.py` | Source-locked journal, `VectorStore`, `query.py` and orchestrator transformations; blocks cache/fast-path bypass in strict mode; dry-run with diffs and backups | Transform compilation, drift rejection, synthetic source tests |
| `tools/amc_release/release_audit28.py` | Exact checkout source-marker and Git-status checks, human-readable reasons; never labels live services/UAT as passed | Local fail-closed tests |
| `install_wave28.py` | Cumulative additive Waves 2.3–2.8 installer, refuse overwrite, symlinks, source drift; explicit apply | Disposable checkout installer tests |
| `.github/workflows/amc-wave28-qualification.yml` | Manual-only source checks, optional Windows/Linux full contract matrix, disposable PostgreSQL Alembic rehearsal, explicit non-release message | YAML structure checks; GitHub Actions **NOT_RUN** |
| `tools/amc_release/tests_wave28/` | New SQL authority, source-patch, vector bridge, migration and installer tests | 65 passed |

### No duplicate architecture

Wave 2.8 **reuses** `amc_publication.Journal`, `PublicationWork`, `PublicationReceipt`, immutable FAISS generations, the Wave 2.7 resolver and the existing `app.vector.client` interface. No replacement publication worker, duplicate outbox or new speculative financial model was created.

## 3. Local test evidence

| Test group | Passed | Basis |
|---|---:|---|
| Wave 2.8 DB authority, resolver, migration, vector bridge, cutover/installer | **65** | Isolated upgraded historical journal + transactional SQLite + fake FAISS reader |
| Prior Waves 2.3–2.7 controls | **338** | Earlier cumulative code and tests |
| Wave 1.9/2.0 historic contracts | **112** | Historical package fixture, not current GitHub checkout |
| **Total pytest tests** | **515** | **0 failed**; 16 additional passing subtests in prior suites |

Local commands executed on the package:

```bash
python -m tools.build_wave28_fixture
PYTHONPATH='test_support/wave28_fixture/backend:.' python -m pytest -q tools/amc_release/tests_wave28
PYTHONPATH='.:test_support/baseline/backend' python -m pytest -q tools/amc_release/tests test_support/baseline/backend/tests/test_wave19_*.py test_support/baseline/backend/tests/test_wave20_*.py
```

Additional checks: Python compilation; manual workflow YAML parsing; frontend JavaScript syntax check; cumulative installer dry-run/apply/idempotency/overwrite refusal; real SQLite migration create/drop. **No PostgreSQL service, Neo4j, live FAISS binary, live browser, production SLO, or GitHub Actions run was executed in this environment.**

## 4. Source integration changes, exact order

1. Obtain the other GitHub account's authorization and fetch the reviewed `amc-dev` baseline. **Do not push directly to `amc-dev`, `main` or an existing UAT branch.** Create `feature/amc-release-candidate-hardening`.
2. Extract this cumulative ZIP *outside* the repository. Run the additive installer dry-run; review collisions; apply only if source inventory is accepted.
3. Apply the source-locked Wave 2.5 and Wave 2.6 journal, worker and governance fixes in that order. These preserve original graph/vector preimages and enforce verified publication. Apply Wave 2.7 `app.main` router wiring. These are **separate from file installation**.
4. Add the Wave 2.8 Alembic migration to the canonical revision DAG. Rehearse in **fresh disposable PostgreSQL and SQLite**, comparing revision heads and schema. Do **not** stamp missing ancestors or automatically backfill active receipt ownership.
5. Dry-run, review and apply the Wave 2.8 source-locked cutover patch to `journal.py`, `vector/client.py`, `retrieval/orchestrator.py`, and `query.py`. The journal binding is committed in the same transaction as `PublicationReceipt`, and authority is suspended before graph mutation, so old answers are not served through an in-progress publication.
6. Run a clean full-checkout backend and frontend suite and inspect all other legacy retrieval paths (`app.engine.faiss_store`, older queries, cached streaming, shadow patches). **No broad serving cutover is permitted while any route bypasses a verified active receipt.**
7. Qualify the new migration, concurrent journal workers/fences, graph readback and rollback, actual FAISS binary reader, and active reader on Linux and Windows. Capture exact-SHA CI and JUnit test identities.
8. In staging only, switch from `AMC_VERIFIED_SERVING_MODE=off` to `enforce` after ingress/auth and ingestion migration tests pass. Refuse unknown mode strings. Validate user-scoped queries, streaming rollback, cache revocation, and performance before any customer traffic.
9. Run 1h/24h SLO windows, a scoped canary and automatic rollback drill; anchor and independently sign all release evidence. Request business UAT only after engineering go/no-go is independently approved.

### Example maintainer commands

```bash
git fetch origin
git switch -c feature/amc-release-candidate-hardening origin/amc-dev
git rev-parse HEAD

# From the extracted ZIP directory (outside repo):
python install_wave28.py --repo /path/to/amc-context-engineering-poc
python install_wave28.py --repo /path/to/amc-context-engineering-poc --apply

# Inside the full AMC checkout:
python -m tools.amc_release.publication_patch25_cli --repo .
python -m tools.amc_release.publication_patch25_cli --repo . --apply
python -m tools.amc_release.publication_patch26_cli --repo .
python -m tools.amc_release.publication_patch26_cli --repo . --apply
python -m tools.amc_release.app_wiring27_cli --repo .
python -m tools.amc_release.app_wiring27_cli --repo . --apply
python -m tools.amc_release.active_cutover28 --repo .
python -m tools.amc_release.active_cutover28 --repo . --apply

# Rehearse schema then test actual AMC source (not bundled reference files):
# DATABASE_URL / AMC_MIGRATION_DATABASE_URL must point to a disposable instance.
cd backend && alembic upgrade head && cd ..
PYTHONPATH=backend python -m pytest -q tools/amc_release/tests_wave28
PYTHONPATH=backend python -m pytest backend/tests -v --tb=short
python -m tools.amc_release.release_audit28 --repo .
```

**Windows PowerShell:** substitute `$env:PYTHONPATH='backend'`; run the same `python -m pytest` invocations. Use the manual Actions workflow for verified Linux/Windows matrix evidence on a committed SHA.

**Backup warning:** Source-locked patchers create `.wave25.bak`, `.wave26.bak`, `.wave27.bak`, `.wave28.bak`; exclude these from commits and ensure the checkout contains no unreviewed source drift. The Wave 2.8 patcher validates Git blob hashes for unchanged vector/query/orchestrator sources, and reviewed prior patch markers for the journal. A review is still required before application.

## 5. Detailed UAT / release gates

| Gate | Required evidence | Current status |
|---|---|---|
| Runtime source cutover | Complete repository, patched imports, all serving routes bound to active authority; no unsafe fallback | **NOT_RUN** |
| Schema migration | Actual checked-out Alembic DAG, PostgreSQL 15 upgrade/rehearsal; no conflicting data | **NOT_RUN** (isolated SQLite 013 passed) |
| Publication correctness | Two active publishers, expired leases, fencing, same-generation separate receipts, crash replay, graph CAS, receipt atomics | **PARTIAL_LOCAL_ONLY** |
| FAISS serving | Actual binary read index, reader load, manifest checksum, pointer/receipt coherence across rollback | **NOT_RUN** (fake reader contracts only) |
| Feedback causality | Active receipt linkage, rollback opens issue, no fabricated successful state | **PARTIAL_LOCAL_ONLY** |
| API security | Authenticated tenant identity, cross-tenant denial, older route/path inspection, no PII leak | **PARTIAL_LOCAL_ONLY** |
| Cross-platform | Exact-commit Windows/Linux run, dependency resolution, frontend/browser tests, same test identities | **NOT_RUN** |
| Performance | Actual p95/p99, 1h and 24h service-level windows, concurrency and recovery timings | **NOT_RUN** |
| Canary/recovery | Real staging canary, fault injection, serving revocation, rollback and health probes | **NOT_RUN** |
| Governance/UAT | External evidence anchors, reviewer signatures, independent go/no-go | **NOT_RUN / BLOCKED** |

### Risks requiring explicit review

- **The existing `VectorStore` is also an ingestion writer.** In strict serving mode the new verified bridge deliberately rejects unverified ingestion writes; the application must separate write/publish from read/serve before enabling enforcement.
- **Not all historical retrieval paths are proven protected.** The source patch protects the v2 orchestrator, both cache entry points, fast path and direct base `VectorStore` read methods. Other direct legacy readers and endpoint variants must be found and disabled or explicitly adapted in the complete repository.
- **Streaming revocation** has partial controls (start-of-request authority, FAISS post-search recheck) but not proven per-token continuous authority. Add a stream cancellation policy and exercise it in staging.
- **Older publication pointers have no authoritative receipt link.** Migration intentionally does not invent associations or automatically activate legacy data. An approved re-publication is required to establish a serving authority.
- **Source patchers have not been applied to the actual checkout here.** Synthetic/source-fragment compilation tests are not full application execution; exact-SHA clean CI remains mandatory.

## 6. Engineering recommendation

**Stop expanding isolated controls after this batch.** The highest-return next operation is a single authenticated feature-branch cutover with a complete checkout and real PostgreSQL/Neo4j/FAISS and browser infrastructure. Until those are available, additional standalone tests yield diminishing returns. The deliverable is now **implementation-ready, not UAT-ready**.

**Final decision: RELEASE BLOCK / UAT BLOCK.**
