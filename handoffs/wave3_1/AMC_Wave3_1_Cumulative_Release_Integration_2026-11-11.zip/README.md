# AMC Wave 3.1 — Cumulative release-candidate hardening

Reviewed public GitHub branch: `nusummit-spg/amc-context-engineering-poc:amc-dev` at SHA `2c0415c4d23a3338428c8314c869299aa0ab771f`.

**Cumulative bundle:** contains engineering source and tests from Waves 2.3–3.1. It supersedes all older cumulative bundles; do not apply each wave independently. **No commit, push, live migration, staging deployment, or UAT acceptance has occurred.**

## Major Wave 3.1 changes

1. Durable **tenant/namespace publication scope** across first publication, retries, later publications and rollback. New table `publication_scope_claim_v31`; migration `014` depends on `013`.
2. Prevent two different works from preparing a graph mutation for a tenant before any active authority exists. A held claim cannot auto-expire just because a worker lease expires; it requires forensic reconciliation.
3. Source-locked **verified-mode bulk promotion guard**: the existing `/api/governance/promote` direct Neo4j route fails with HTTP 503 when `AMC_VERIFIED_SERVING_MODE=enforce`.
4. Read-only orphan/held-claim auditor; a missing migration yields BLOCKED rather than a false empty report.
5. One clean branch bootstrap `python -m tools.amc_release.apply_all31 --repo <checkout> --bundle .` (dry run first, then append `--apply`); cumulative source-patch sequence is validated before any branch write.
6. Cross-platform deterministic JUnit test runner `python -m tools.amc_release.run_wave31_tests --root . --offline` (for extracted archive), plus manual-only Windows/Linux CI. Exact-source qualification remains fail-closed.

## Local offline verification

From extracted ZIP root, with Python, pytest, SQLAlchemy, Alembic, FastAPI and PyYAML available:

```bash
python -m tools.amc_release.run_wave31_tests --root . --offline --out remediation/wave3_1/LOCAL_TEST_EVIDENCE.json
```

This tests the **bundled reference implementation**, not the full GitHub checkout. Tests need no remote calls or secrets. The command returns a nonzero exit code on failure; the report always states UAT=BLOCKED.

## Prepare an actual feature branch (authorized maintainer, clean SHA-pinned checkout)

```powershell
# Run in extracted bundle directory:
python -m tools.amc_release.apply_all31 --repo C:\code\amc-context-engineering-poc --bundle .
# Review preflight. Then ONLY on a clean exact-SHA checkout:
python -m tools.amc_release.apply_all31 --repo C:\code\amc-context-engineering-poc --bundle . --apply
```

The integration bootstrap creates only a **local, uncommitted branch**, never pushes/deploys. Review the branch diff and `.wave*.bak` backups; do not commit backups. Run Alembic 014 first on **disposable PostgreSQL**, verify migration history, run exact-SHA Windows/Linux regression and evaluate live infrastructure before granting UAT.

For the implementation details, read `remediation/wave3_1/IMPLEMENTATION.md` and the separate root-level Markdown handoff. Older Wave 2.9/3.0 instructions are kept as historical references only.

**Release / production / UAT: BLOCKED.**
